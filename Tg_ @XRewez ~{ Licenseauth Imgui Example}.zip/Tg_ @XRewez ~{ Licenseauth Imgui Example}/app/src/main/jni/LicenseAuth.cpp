-#include <LicenseAuth.hpp>
bool isLogin = false;
static std::string hexDecode(const std::string& hex);
bool constantTimeStringCompare(const char* str1, const char* str2, size_t length);
std::string signature;
std::string Date;
bool initalized;
std::string appname = XorStr("APP_NAME"); // application name. right above the blurred text aka the secret on the licenses tab among other tabs
std::string ownerid = XorStr("Owner_ID"); // ownerid, found in account settings. click your profile picture on top right of dashboard and then account settings.
std::string secret = XorStr("Secret"); // app secret, the blurred text on licenses tab and other tabs
std::string version = XorStr("1.0"); // leave alone unless you've changed version on website
std::string url = XorStr("https://licenseauth.xyz/api/1.3/");
std::string sellerkey = XorStr("Seller_Key");
std::string chatname = XorStr("Chat_Name");
std::string path = XorStr(""); 
using namespace LicenseAuth;
api LicenseAuthApp(appname, ownerid, secret, version, url, path);
static std::string username;
static std::string password;
static std::string key;
static std::string email;
static std::string newusername;
static std::string input;
std::string OnlineUser;
std::string getkey;
bool exists(const std::string& path) {
    struct stat buffer;
    return (stat(path.c_str(), &buffer) == 0);
}
void LicenseAuth::api::init()
{
    CURL* curl = curl_easy_init();
    auto data =
        XorStr("type=init") +
        XorStr("&ver=") + version +
        XorStr("&name=") + curl_easy_escape(curl, name.c_str(), 0) +
        XorStr("&ownerid=") + ownerid;

    auto response = req(data, url);

    if (response == XorStr("LicenseAuth_Invalid")) {

    }

    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];
    
    load_response_data(json);

    if (json[(XorStr("success"))])
    {
        if (json[(XorStr("newSession"))]) {
            sleep(100);
        }
        sessionid = json[(XorStr("sessionid"))];
        initalized = true;
        load_app_data(json[(XorStr("appinfo"))]);
    }
    else if (json[(XorStr("message"))] == XorStr("invalidver"))
    {
        std::string dl = json[(XorStr("download"))];
        if (dl == "")
        {
        }
        else
        {
        }
    }
}
size_t write_callback(void* contents, size_t size, size_t nmemb, void* userp) {
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}
static size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* s) {
    size_t newLength = size * nmemb;
    try {
        s->append(static_cast<char*>(contents), newLength);
    } catch (std::bad_alloc& e) {
        return 0;
    }
    return newLength;
}
static size_t header_callback(char* buffer, size_t size, size_t nitems, void* userdata)
{
    // thanks to https://stackoverflow.com/q/28537837 and https://stackoverflow.com/a/66660987
    std::string temp = std::string(buffer);
    if (temp.substr(0, 9) == "signature") {
        std::string parsed = temp.erase(0, 11);; // remove "signature: "  from string 
        signature = parsed.substr(0, 64); // if I don't this, there's an extra line. so yeah.
    }
    std::string* headers = (std::string*)userdata;
    headers->append(buffer, nitems * size);
    return nitems * size;
}

void LicenseAuth::api::login(std::string username, std::string password)
{
    std::string hwid = getHwid(getkey);
    auto data =
        XorStr("type=login") +
        XorStr("&username=") + username +
        XorStr("&pass=") + password +
        XorStr("&hwid=") + hwid +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];
    load_response_data(json);
    if (json[(XorStr("success"))])
        load_user_data(json[(XorStr("info"))]);
}
void LicenseAuth::api::chatget(std::string channelname)
{
        auto data =
        XorStr("type=chatget") +
        XorStr("&channel=") + channelname +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
        auto response = req(data, url);
        auto json = response_decoder.parse(response);
        load_channel_data(json);
}
bool LicenseAuth::api::chatsend(std::string message, std::string channel)
{
    auto data =
        XorStr("type=chatsend") +
        XorStr("&message=") + message +
        XorStr("&channel=") + channel +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;

    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    load_response_data(json);
    return json[("success")];
}

void LicenseAuth::api::changeUsername(std::string newusername)
{
    auto data =
        XorStr("type=changeUsername") +
        XorStr("&newUsername=") + newusername +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;

    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];

    load_response_data(json);
}
void LicenseAuth::api::regstr(std::string username, std::string password, std::string key, std::string email) {

    std::string hwid = getHwid(getkey);
    auto data =
        XorStr("type=register") +
        XorStr("&username=") + username +
        XorStr("&pass=") + password +
        XorStr("&key=") + key +
        XorStr("&email=") + email +
        XorStr("&hwid=") + hwid +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];
    load_response_data(json);
    if (json[(XorStr("success"))])
        load_user_data(json[(XorStr("info"))]);
}

void LicenseAuth::api::upgrade(std::string username, std::string key) {
    auto data =
        XorStr("type=upgrade") +
        XorStr("&username=") + username +
        XorStr("&key=") + key +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];
    json[(XorStr("success"))] = false;
    load_response_data(json);
}

void LicenseAuth::api::license(std::string key) {
    std::string hwid = getHwid(getkey);
    auto data =
        XorStr("type=license") +
        XorStr("&key=") + key +
        XorStr("&hwid=") + hwid +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];
if (json[("success")]) {
        getkey = key;
        }
    load_response_data(json);
    if (json[(XorStr("success"))])
        load_user_data(json[(XorStr("info"))]);
}

void LicenseAuth::api::setvar(std::string var, std::string vardata) {
    auto data =
        XorStr("type=setvar") +
        XorStr("&var=") + var +
        XorStr("&data=") + vardata +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    load_response_data(json);
}

std::string LicenseAuth::api::getvar(std::string var) {
    auto data =
        XorStr("type=getvar") +
        XorStr("&var=") + var +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];

    load_response_data(json);
    return !json[(XorStr("response"))].is_null() ? json[(XorStr("response"))] : XorStr("");
}

void LicenseAuth::api::ban(std::string reason) {
    auto data =
        XorStr("type=ban") +
        XorStr("&reason=") + reason +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];
    load_response_data(json);
}

bool LicenseAuth::api::checkblack(std::string username) {
    std::string hwid = getHwid(getkey);
    auto data =
        XorStr("type=checkblacklist") +
        XorStr("&hwid=") + hwid +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];
    return json[("success")];
}

void LicenseAuth::api::check() {
    auto data =
        XorStr("type=check") +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;

    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];

    load_response_data(json);
}

std::string LicenseAuth::api::var(std::string varid) {
    auto data =
        XorStr("type=var") +
        XorStr("&varid=") + varid +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];

    load_response_data(json);
    return json[(XorStr("message"))];
}

std::vector<unsigned char> LicenseAuth::api::download(std::string fileid) {
    auto to_uc_vector = [](std::string value) {
        return std::vector<unsigned char>(value.data(), value.data() + value.length() );
    };


    auto data =
        XorStr("type=file") +
        XorStr("&fileid=") + fileid +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=").c_str() + ownerid;

    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];

    load_response_data(json);
    if (json[ XorStr( "success" ) ])
    {
        auto file = hexDecode(json[ XorStr( "contents" )]);
        return to_uc_vector(file);
    }
    return {};
}


std::string LicenseAuth::api::webhook(std::string id, std::string params, std::string body, std::string contenttype)
{
    CURL *curl = curl_easy_init();
    auto data =
        XorStr("type=webhook") +
        XorStr("&webid=") + id +
        XorStr("&params=") + curl_easy_escape(curl, params.c_str(), 0) +
        XorStr("&body=") + curl_easy_escape(curl, body.c_str(), 0) +
        XorStr("&conttype=") + contenttype +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    curl_easy_cleanup(curl);
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];
    load_response_data(json);
    return !json[(XorStr("response"))].is_null() ? json[(XorStr("response"))] : XorStr("");
}

std::string LicenseAuth::api::fetchonline() 
{
    auto data =
        XorStr("type=fetchOnline") +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;

    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];

    std::string onlineusers;

    int y = atoi(api::app_data.numOnlineUsers.c_str());
    for (int i = 0; i < y; i++)
    {
        onlineusers.append(json[XorStr("users")][i][XorStr("credential")]); onlineusers.append(XorStr("\n"));
    }

    return onlineusers;
}

void LicenseAuth::api::fetchstats()
{
    auto data =
        XorStr("type=fetchStats") +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;

    auto response = req(data, url);

    auto json = response_decoder.parse(response);
    std::string message = json[(XorStr("message"))];
    load_response_data(json);

    if (json[(XorStr("success"))])
        load_app_data(json[(XorStr("appinfo"))]);
}

void LicenseAuth::api::forgot(std::string username, std::string email)
{
    auto data =
        XorStr("type=forgot") +
        XorStr("&username=") + username +
        XorStr("&email=") + email +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    load_response_data(json);
}

void LicenseAuth::api::logout() {
    auto data =
        XorStr("type=logout") +
        XorStr("&sessionid=") + sessionid +
        XorStr("&name=") + name +
        XorStr("&ownerid=") + ownerid;
    auto response = req(data, url);
    auto json = response_decoder.parse(response);
    if (json[(XorStr("success"))]) {

        //clear all old user data from program
        user_data.createdate.clear();
        user_data.ip.clear();
        user_data.hwid.clear();
        user_data.lastlogin.clear();
        user_data.username.clear();
        user_data.subscriptions.clear();

        //clear sessionid
        sessionid.clear();
        isLogin = false;
    }

    load_response_data(json);
}
std::string LicenseAuth::api::req(std::string data, std::string url) {
    CURL* curl = curl_easy_init();
    if (!curl)
        return XorStr("null");
    std::string response_string;
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data.c_str());
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L); // Disable peer verification
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L); // Disable host verification
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_string);
    CURLcode res = curl_easy_perform(curl);
            if (res != CURLE_OK) {
                std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
            } else {
                json response_json;
                try {
                    response_json = json::parse(response_string);
                    if (response_json["success"].get<bool>()) {
                   //     initialized = true;
                    } else {
                        std::cout << "Initialization failed: " << response_json["message"].get<std::string>() << std::endl;
                    }
                } catch (const json::exception& e) {
                    std::cerr << "Error parsing JSON: " << e.what() << std::endl;
                }
            }
    curl_easy_cleanup(curl);
    return response_string;
}
static std::string hexDecode(const std::string& hex)
{
    int len = hex.length();
    std::string newString;
    for (int i = 0; i < len; i += 2)
    {
        std::string byte = hex.substr(i, 2);
        char chr = (char)(int)strtol(byte.c_str(), NULL, 16);
        newString.push_back(chr);
    }
    return newString;
}
std::string tm_to_readable_time(std::tm ctx) {
    char buffer[80];
    strftime(buffer, sizeof(buffer), "%Y/%m/%d %I:%M %p", &ctx); // Format for year-month-day hour:minute AM/PM
    return std::string(buffer);
}
std::string tm_to_readable_time_new(std::tm ctx) {
    char buffer[80];
    // استخدام تنسيق "%B %d" للحصول على اسم الشهر الكامل ورقم اليوم
    strftime(buffer, sizeof(buffer), "%B %d", &ctx);
    return std::string(buffer);
}
std::string tm_to_readable_time_msg(std::tm ctx) {
    char buffer[80];
    strftime(buffer, sizeof(buffer), "%I:%M %p", &ctx); // Format for year-month-day hour:minute AM/PM
    return std::string(buffer);
}
static std::time_t string_to_timet(std::string timestamp) {
    auto cv = strtol(timestamp.c_str(), NULL, 10); // long
    return static_cast<time_t>(cv);
}

static std::tm timet_to_tm(time_t timestamp) {
    std::tm context;
    localtime_r(&timestamp, &context); // Use localtime_r for thread safety
    return context;
}
bool constantTimeStringCompare(const char* str1, const char* str2, size_t length) {
    int result = 0;

    for (size_t i = 0; i < length; ++i) {
        result |= str1[i] ^ str2[i];
    }

    return result == 0;
}
#include <iostream>
#include <unistd.h>
#include <limits.h> // يحتوي على تعريف PATH_MAX
std::string get_current_path() {
    char buffer[PATH_MAX]; // PATH_MAX هو الحد الأقصى لطول المسار
    if (getcwd(buffer, sizeof(buffer)) != nullptr) {
        return std::string(buffer);
    } else {
        return "Error retrieving current path";
    }
}
std::string getPath() {
    const char* programDataPath = std::getenv("ALLUSERSPROFILE");

    if (programDataPath != nullptr) {
        return std::string(programDataPath);
    }
    else {

        return get_current_path();
    }
}

void RedactField(nlohmann::json& jsonObject, const std::string& fieldName)
{

    if (jsonObject.contains(fieldName)) {
        jsonObject[fieldName] = "REDACTED";
    }
}
