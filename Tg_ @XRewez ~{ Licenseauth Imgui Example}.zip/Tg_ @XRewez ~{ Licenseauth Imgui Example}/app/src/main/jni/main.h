#pragma once

#include "Includes/Includes.h"
#include "Includes/obfuscate.h"
#include "Includes/Tools.h"
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui/imgui.h"
#include "imgui/imgui_styles.h"
#include "imgui/backends/imgui_impl_android.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "Includes/json.hpp"
#include "Includes/tahoma.h"
using json = nlohmann::json;
using namespace std;
#include "StrEnc.h"
android_app *g_App = nullptr;
#include <android_app.cpp>
int screenWidth = -1, glWidth, screenHeight = -1, glHeight;
#include "Includes/Fonts.hpp"
#include "User.h"
uintptr_t UE4;
#include <cstring>
#include "xorstr.hpp"
#include <curl/curl.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#define SLEEP_TIME 1000LL / 90LL
bool initImGui = false;
float density = -1;
static bool opened = true;
static bool activehack = true;
bool ifismembotenable = false;
int selectedTab = 1;
#define STB_IMAGE_IMPLEMENTATION
#include "imgui/stb_image.h"
std::string GetPackageNameString() {
    FILE *f = fopen("/proc/self/cmdline", "rb");
    if (f) {
        char *buf = new char[64];
        fread(buf, sizeof(char), 64, f);
        fclose(f);
        return buf;
    }
    return 0;
}
struct TextureInfo{
    ImTextureID textureID;
    int w; 
    int h;
};

TextureInfo CreateTexture(const unsigned char* buf, int len)
{
    TextureInfo image;
   
    unsigned char* image_data = stbi_load_from_memory(buf, len, &image.w, &image.h, NULL, 0);
    if (image_data == NULL)
        perror("文件不存在");
    
    GLuint image_texture;
    glGenTextures(1, &image_texture);
    glBindTexture(GL_TEXTURE_2D, image_texture);

 
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); 
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);


    #if defined(GL_UNPACK_ROW_LENGTH) && !defined(__EMSCRIPTEN__)
    glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
    #endif    
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image.w, image.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data);
    stbi_image_free(image_data);
    image.textureID = image_texture;

    return image;
}
TextureInfo User;
void AddUnderLine(ImColor col_)
{
    ImVec2 min = ImGui::GetItemRectMin();
    ImVec2 max = ImGui::GetItemRectMax();
    min.y = max.y;
    ImGui::GetWindowDrawList()->AddLine(min, max, col_, 1.0f);
}
void TextURL(const char *name_, const char *URL_, uint8_t SameLineBefore_, uint8_t SameLineAfter_)
{
    if (1 == SameLineBefore_)
    {
        ImGui::SameLine(0.0f, ImGui::GetStyle().ItemInnerSpacing.x);
    }
	
	ImGui::PushStyleColor(ImGuiCol_Text, {255, 255, 255, 255});
    ImGui::Text(name_);
    ImGui::PopStyleColor();
	
    if (ImGui::IsItemHovered())
    {
        if (ImGui::IsMouseClicked(0))
        {
            OpenURL(URL_);
        }
        AddUnderLine({255, 193, 000, 255});
     //   ImGui::SetTooltip(ICON_FA_LINK "  Open in browser\n%s", URL_);
    }
    else
    {
        AddUnderLine({255, 255, 255, 255});
    }
    if (1 == SameLineAfter_)
    {
        ImGui::SameLine(0.0f, ImGui::GetStyle().ItemInnerSpacing.x);
    }
}
void linevertical()
    {
        ImGui::SameLine();
        ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);
        ImGui::SameLine();
}
#include <iostream>
#include <fstream>

bool FileExists(const std::string& filename) {
    std::ifstream file(filename);
    return file.good();
}
