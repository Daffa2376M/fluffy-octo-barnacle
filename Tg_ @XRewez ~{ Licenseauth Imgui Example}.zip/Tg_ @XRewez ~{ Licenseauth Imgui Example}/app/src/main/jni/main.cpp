#include "main.h"
#include "LicenseAuth.cpp"
#include "skStr.h"
#include "utils.hpp"
#include "imgui/imgui_Keyboard.h"
#include "imgui/imgui_notify.h"
#define GNativeAndroidApp_Offset 0x9a02f38
struct sRegion
{
	uintptr_t start, end;
};
std::vector<sRegion> trapRegions;
// ======================================================================== //
using namespace LicenseAuth;
// ======================================================================== //
 std::vector<channel_struct> ChatMessages;
void Messages()
{
    while (true)
    {
        if (isLogin)
        {
            std::string NewOnlineUser;
            NewOnlineUser = LicenseAuthApp.fetchonline();
            if (OnlineUser != NewOnlineUser) {
                OnlineUser = NewOnlineUser;
            }
            LicenseAuthApp.fetchstats();
            std::vector<channel_struct> newMessages;
            LicenseAuthApp.chatget(chatname.c_str());
            newMessages = LicenseAuthApp.response.channeldata;
            for (const auto& msg : newMessages)
            {
               
                if (std::find(ChatMessages.begin(), ChatMessages.end(), msg) == ChatMessages.end())
                {
                    ChatMessages.push_back(msg);
                }
            }

            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}
void GetNewMessages()
{
    std::string lastMessage;
    while (true)
    {
       if (isLogin)
        {
                if (lastMessage != ChatMessages.back().message)
                {
                    lastMessage = ChatMessages.back().message;
                    std::string msgg = "New Message [" + ChatMessages.back().message + "] : \n" + ChatMessages.back().author;
                    ImGui::InsertNotification({ ImGuiToastType_Info, 3000, msgg.c_str(), "Server" });
                }
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}
void SendMessages()
{
    while (true)
    {
        if (isLogin && selectedTab == 1)
        {
            LicenseAuthApp.chatsend(input.c_str(), chatname.c_str()); //chat name
            input.clear();
            std::this_thread::sleep_for(std::chrono::seconds(1));
            return;
        }
    }
}
std::string tm_to_readable_time(tm ctx);
static std::time_t string_to_timet(std::string timestamp);
static std::tm timet_to_tm(time_t timestamp);
const std::string compilation_date = (std::string)skCrypt(__DATE__);
const std::string compilation_time = (std::string)skCrypt(__TIME__);
void BeginDraw() {
    std::string FileInfo;
    FileInfo += "/storage/emulated/0/Android/data/";                  
    FileInfo += GetPackageNameString().c_str();          
    FileInfo += "/files/test.json";
    ImGui::SetNextWindowPos(ImVec2(glWidth / 2 * 0.5, glHeight / 2 * 0.5 - 150), ImGuiCond_Once);
    ImGui::SetNextWindowSize({ 500, 400 });
    static bool checkkey = false;
    if (!isLogin) {
    if (!checkkey && FileExists(FileInfo)) {
        if (CheckIfJsonKeyExists(FileInfo.c_str(), "license")) {
            std::string key = ReadFromJson(FileInfo.c_str(), "license");
            LicenseAuthApp.license(key);
            if (LicenseAuthApp.response.success) {
            ImGui::InsertNotification({ ImGuiToastType_Success, 3000, "Successfully Automatically Logged In", "Login System" });
            isLogin = true;
            }
        } else if (CheckIfJsonKeyExists(FileInfo.c_str(), "username")) {
            std::string username = ReadFromJson("test.json", "username");
            std::string password = ReadFromJson("test.json", "password");
            LicenseAuthApp.login(username, password);
            if (LicenseAuthApp.response.success) {
            ImGui::InsertNotification({ ImGuiToastType_Success, 3000, "Successfully Automatically Logged In", "Login System" });
            isLogin = true;
            }
        }
        checkkey = true;
        }
        }
    if (ImGui::Begin("@CPP_Codes_Channel - LicenseAuth v1.3 Example", NULL)) {
        if (!isLogin) {
        static bool Login1 = false, Login2 = true, Forgot = false, Register = false, Upgrade = false;
        if (Login1) {
            ImGui::KeypadEditString("Input Your Username...", &username);
            ImGui::SameLine();
            if (ImGui::Button("Paste##User", ImVec2(0, 0))){
            auto key = getClipboardText();
            username.resize(key.size() + 1);
            strncpy(&username[0], key.c_str(), key.size());
            username[key.size()] = '\0';
            }
            ImGui::KeypadEditString("Input Your Password...", &password);
            ImGui::PopupKeypad(NULL);
            ImGui::SameLine();
            if (ImGui::Button("Paste##Pass", ImVec2(0, 0))){
            auto key = getClipboardText();
            password.resize(key.size() + 1);
            strncpy(&password[0], key.c_str(), key.size());
            password[key.size()] = '\0';
            }
            if (ImGui::Button("Login", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
            LicenseAuthApp.login(username, password);
            ImGui::InsertNotification({ ImGuiToastType_Success, 3000, ("Status: "+LicenseAuthApp.response.message).c_str(), "Login System" });
            if (LicenseAuthApp.response.success) {
            WriteToJson(FileInfo.c_str(), "username", username, true, "password", password);
            ImGui::InsertNotification({ ImGuiToastType_Success, 3000, "Successfully Created File For Auto Login", "Login System" });
            isLogin = true;
            }
            }
            if (ImGui::Button("Login By License", ImVec2(ImGui::GetContentRegionAvail().x/2,0))) {
                Login1 = false;
                Login2 = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Upgrade Key", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
                Login1 = false;
                Upgrade = true;
            }
            if (ImGui::Button("Forgot", ImVec2(ImGui::GetContentRegionAvail().x/2,0))) {
                Login1 = false;
                Forgot = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Register Key", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
                Login1 = false;
                Register = true;
            }
            }// End Login1
            if (Login2) {
            ImGui::KeypadEditString("Input Your license...", &key);
            ImGui::PopupKeypad(NULL);
            ImGui::SameLine();
            if (ImGui::Button("Paste##Key", ImVec2(0, 0))){
            auto keyClibpboard = getClipboardText();
            key.resize(keyClibpboard.size() + 1);
            strncpy(&key[0], keyClibpboard.c_str(), keyClibpboard.size());
            key[keyClibpboard.size()] = '\0';
            }
            if (ImGui::Button("Login", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
            LicenseAuthApp.license(key);
            ImGui::InsertNotification({ ImGuiToastType_Success, 3000, ("Status: "+LicenseAuthApp.response.message).c_str(), "Login System" });
            if (LicenseAuthApp.response.success) {
            WriteToJson(FileInfo.c_str(), "license", key, false, "", "");
            ImGui::InsertNotification({ ImGuiToastType_Success, 3000, "Successfully Created File For Auto Login", "Login System" });
            isLogin = true;
            }
            }
            if (ImGui::Button("Login By User & Pass", ImVec2(ImGui::GetContentRegionAvail().x/2,0))) {
                Login1 = true;
                Login2 = false;
            }
            ImGui::SameLine();
            if (ImGui::Button("Upgrade Key", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
                Login2 = false;
                Upgrade = true;
            }
            if (ImGui::Button("Forgot", ImVec2(ImGui::GetContentRegionAvail().x/2,0))) {
                Login2 = false;
                Forgot = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Register Key", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
                Login2 = false;
                Register = true;
            }
            }// End Login2
            if (Upgrade) {
            ImGui::KeypadEditString("Input Your Username...", &username);
            ImGui::SameLine();
            if (ImGui::Button("Paste##username", ImVec2(0, 0))){
            auto keyClibpboard = getClipboardText();
            username.resize(keyClibpboard.size() + 1);
            strncpy(&username[0], keyClibpboard.c_str(), keyClibpboard.size());
            username[keyClibpboard.size()] = '\0';
            }
            ImGui::KeypadEditString("Input Your license...", &key);
            ImGui::PopupKeypad(NULL);
            ImGui::SameLine();
            if (ImGui::Button("Paste##license", ImVec2(0, 0))){
            auto keyClibpboard = getClipboardText();
            key.resize(keyClibpboard.size() + 1);
            strncpy(&key[0], keyClibpboard.c_str(), keyClibpboard.size());
            key[keyClibpboard.size()] = '\0';
            }
            if (ImGui::Button("Upgrade", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
            LicenseAuthApp.upgrade(username, key);
            ImGui::InsertNotification({ ImGuiToastType_Success, 3000, ("Status: "+LicenseAuthApp.response.message).c_str(), "Login System" });
            }
            if (ImGui::Button("Login By License", ImVec2(ImGui::GetContentRegionAvail().x/2,0))) {
                Upgrade = false;
                Login2 = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Login By User & Pass", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
                Upgrade = false;
                Login2 = true;
            }
            if (ImGui::Button("Forgot", ImVec2(ImGui::GetContentRegionAvail().x/2,0))) {
                Upgrade = false;
                Forgot = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Register Key", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
                Upgrade = false;
                Register = true;
            }
            }// End Upgrade
            if (Forgot) {
            ImGui::KeypadEditString("Input Your Username...", &username);
            ImGui::SameLine();
            if (ImGui::Button("Paste##User", ImVec2(0, 0))){
            auto key = getClipboardText();
            username.resize(key.size() + 1);
            strncpy(&username[0], key.c_str(), key.size());
            username[key.size()] = '\0';
            }
            ImGui::KeypadEditString("Input Your Email...", &email);
            ImGui::SameLine();
            if (ImGui::Button("Paste##Email", ImVec2(0, 0))){
            auto key = getClipboardText();
            email.resize(key.size() + 1);
            strncpy(&email[0], key.c_str(), key.size());
            email[key.size()] = '\0';
            }
            if (ImGui::Button("Forgot", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
            LicenseAuthApp.forgot(username, email);
            ImGui::InsertNotification({ ImGuiToastType_Success, 3000, ("Status: "+LicenseAuthApp.response.message).c_str(), "Login System" });
            }
            if (ImGui::Button("Login By User & Pass", ImVec2(ImGui::GetContentRegionAvail().x/2,0))) {
                Forgot = false;
                Login1= true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Login By License", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
                Forgot = false;
                Login2 = true;
            }
            if (ImGui::Button("Upgrade Key", ImVec2(ImGui::GetContentRegionAvail().x/2,0))) {
                Forgot = false;
                Upgrade = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Register Key", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
                Forgot = false;
                Register = true;
            }
            }// End Forgot
            if (Register) {
            ImGui::KeypadEditString("Input Your Username...", &username);
            ImGui::SameLine();
            if (ImGui::Button("Paste##User", ImVec2(0, 0))){
            auto key = getClipboardText();
            username.resize(key.size() + 1);
            strncpy(&username[0], key.c_str(), key.size());
            username[key.size()] = '\0';
            }
            ImGui::KeypadEditString("Input Your Password...", &password);
            ImGui::SameLine();
            if (ImGui::Button("Paste##Pass", ImVec2(0, 0))){
            auto key = getClipboardText();
            password.resize(key.size() + 1);
            strncpy(&password[0], key.c_str(), key.size());
            password[key.size()] = '\0';
            }
            ImGui::KeypadEditString("Input Your license...", &key);
            ImGui::PopupKeypad(NULL);
            ImGui::SameLine();
            if (ImGui::Button("Paste##Key", ImVec2(0, 0))){
            auto keyClipboard = getClipboardText();
            key.resize(keyClipboard.size() + 1);
            strncpy(&key[0], keyClipboard.c_str(), keyClipboard.size());
            key[keyClipboard.size()] = '\0';
            }
            if (ImGui::Button("Regstr", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
            LicenseAuthApp.regstr(username, password, key);
            ImGui::InsertNotification({ ImGuiToastType_Success, 3000, ("Status: "+LicenseAuthApp.response.message).c_str(), "Login System" });
            }
            if (ImGui::Button("Login By License", ImVec2(ImGui::GetContentRegionAvail().x/2,0))) {
                Register = false;
                Login2 = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Login By User & Pass", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
                Register = false;
                Login2 = true;
            }
            if (ImGui::Button("Forgot", ImVec2(ImGui::GetContentRegionAvail().x/2,0))) {
                Register = false;
                Forgot = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Upgrade Key", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
                Register = false;
                Upgrade = true;
            }
            }// End Register
        ImGui::Text(LicenseAuthApp.response.message.c_str());
        } else if (isLogin) {
        ImGui::TextColored(ImColor(0,255,0,255), ("Online Users: " + OnlineUser).c_str());
        if (ImGui::Button("Logout", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
            LicenseAuthApp.logout();
            LicenseAuthApp.init();
        }
                        if (ImGui::BeginTabBar("##Bar")) {
                        if (ImGui::BeginTabItem("Account Info")) {
                            ImGui::Text(("Username: "+LicenseAuthApp.user_data.username).c_str());
                            ImGui::Text(("IP Address: "+LicenseAuthApp.user_data.ip).c_str());
                            ImGui::Text(("Hardware-Id: "+LicenseAuthApp.user_data.hwid).c_str());
                            ImGui::Text(("Create date: "+tm_to_readable_time(timet_to_tm(string_to_timet(LicenseAuthApp.user_data.createdate)))).c_str());
                            ImGui::Text(("Last login: "+tm_to_readable_time(timet_to_tm(string_to_timet(LicenseAuthApp.user_data.lastlogin)))).c_str());
                            ImGui::Text("Subscription(s): ");
                            for (int i = 0; i < LicenseAuthApp.user_data.subscriptions.size(); i++) {
                                auto sub = LicenseAuthApp.user_data.subscriptions.at(i);
                                ImGui::Text(("\nname: "+ sub.name + " expiry:" + tm_to_readable_time(timet_to_tm(string_to_timet(sub.expiry)))).c_str());
                            }
                            ImGui::EndTabItem();
                        }
                        if (ImGui::BeginTabItem("App Server")) {
                        ImGui::Text(("Num Users: "+ LicenseAuthApp.app_data.numUsers).c_str());
                        ImGui::Text(("Num Online Users: "+ LicenseAuthApp.app_data.numOnlineUsers).c_str());
                        ImGui::Text(("Num Keys: "+ LicenseAuthApp.app_data.numKeys).c_str());
                        ImGui::Text(("Version: "+ LicenseAuthApp.app_data.version).c_str());
                        
                        ImGui::EndTabItem();
                        }
                        if (ImGui::BeginTabItem("Files")) {
                            ImGui::Text("Download file by id from server");
                            static std::string file_id;
                            ImGui::KeypadEditString("Input File Id (Number)...", &file_id);
                            ImGui::PopupKeypad(NULL);
                            if (ImGui::Button("Download File")) {
                                std::vector<std::uint8_t> bytes = LicenseAuthApp.download(file_id);
                                std::ofstream file("file.dll", std::ios_base::out | std::ios_base::binary);
                                file.write((char*)bytes.data(), bytes.size());
                                file.close();
                            }
                            ImGui::EndTabItem();
                        }
                        if (ImGui::BeginTabItem("Chat-Server")) {
                            for (channel_struct msg : ChatMessages) {
                                //auto msg = LicenseAuthApp.response.channeldata[i];
                                    ImGui::TextWrapped("[%s] %s: %s", tm_to_readable_time(timet_to_tm(string_to_timet(msg.timestamp.c_str()))).c_str(), msg.author.c_str(), msg.message.c_str());
                             }
                             if (ImGui::Button("Paste", ImVec2(90, 0))){
                             auto key = getClipboardText();
                             input.resize(key.size() + 1);
                             strncpy(&input[0], key.c_str(), key.size());
                             input[key.size()] = '\0';
                             }
                             ImGui::SameLine();
                             ImGui::PushItemWidth(ImGui::GetContentRegionAvail().x - 90);
                             ImGui::KeypadEditString("Messages...", &input);
                             ImGui::PopupKeypad(NULL);
                             ImGui::SameLine();
                             if (ImGui::Button(XorStr("Send").c_str(), ImVec2(ImGui::GetContentRegionAvail().x, 0))) {
                                new std::thread(SendMessages);
                             }
                             ImGui::EndTabItem();
                        }
                        if (ImGui::BeginTabItem("Settings")) {
                            ImGui::BulletText("Change Username: ");
                            ImGui::KeypadEditString("Input Your Username...", &newusername);
                            ImGui::PopupKeypad(NULL);
                            ImGui::SameLine();
                            if (ImGui::Button("Paste##Key", ImVec2(0, 0))){
                                auto keyClibpboard = getClipboardText();
                                newusername.resize(keyClibpboard.size() + 1);
                                strncpy(&newusername[0], keyClibpboard.c_str(), keyClibpboard.size());
                                newusername[keyClibpboard.size()] = '\0';
                                }
            if (ImGui::Button("Change Username", ImVec2(ImGui::GetContentRegionAvail().x,0))) {
            LicenseAuthApp.changeUsername(newusername);
            }
            ImGui::EndTabItem();
                        }
                    ImGui::EndTabBar();
                }
                }// End isLogin
    }// End Begin
}// Draw
// ======================================================================== //
EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean _eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
    if (glWidth <= 0 || glHeight <= 0)
        return orig_eglSwapBuffers(dpy, surface);

    if (!g_App)
        return orig_eglSwapBuffers(dpy, surface);

    screenWidth = ANativeWindow_getWidth(g_App->window);
    screenHeight = ANativeWindow_getHeight(g_App->window);
    density = AConfiguration_getDensity(g_App->config);
    if (!initImGui) {
        LicenseAuthApp.init();
        ImGui::CreateContext();
		ImGuiIO& io = ImGui::GetIO(); (void)io;
		ImGuiStyle *style = &ImGui::GetStyle();
        ImGui::StyleColorsDark(style);
        ImGui_ImplAndroid_Init();
        ImGui_ImplOpenGL3_Init("#version 300 es");
		static const ImWchar icons_ranges[] = { ICON_MIN_FA	, ICON_MAX_FA, 0 };
		ImFontConfig icons_config;
		icons_config.MergeMode = true;
		icons_config.PixelSnapH = true;
		icons_config.OversampleH = 3;
		icons_config.OversampleV = 3;
		ImFontConfig font_cfg;
    	font_cfg.FontDataOwnedByAtlas = false;
	    io.Fonts->AddFontFromMemoryTTF((void*)tahoma, sizeof(tahoma), 20.0f, &font_cfg);
	    io.Fonts->AddFontFromMemoryTTF((void*)fontAwesome, sizeof(fontAwesome), 20, &icons_config, icons_ranges);
	    User = CreateTexture(user, sizeof(user));
        initImGui = true;	
    }

        ImGuiIO &io = ImGui::GetIO();
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplAndroid_NewFrame(glWidth, glHeight);
        ImGui::NewFrame();
		BeginDraw();// Menu
        ImGui::RenderNotifications(); // Render Notfity
	    ImGui::End();
	    ImGui::Render();
    	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
	    return orig_eglSwapBuffers(dpy, surface);
}
int32_t (*orig_onInputEvent)(struct android_app *app, AInputEvent *inputEvent);
int32_t onInputEvent(struct android_app *app, AInputEvent *inputEvent) {
    if (initImGui) {
        ImGui_ImplAndroid_HandleInputEvent(inputEvent, {(float) screenWidth / (float) glWidth, (float) screenHeight / (float) glHeight});
    }
    return orig_onInputEvent(app, inputEvent);
}
[[noreturn]] void *maps_thread(void *)
{
	while (true)
	{
		
		auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
		std::vector<sRegion> tmp;
		char line[512];
		FILE *f = fopen("/proc/self/maps", "r");
		if (f)
		{
			while (fgets(line, sizeof line, f))
			{
				uintptr_t start, end;
				char tmpProt[16];
				if (sscanf(line, "%" PRIXPTR "-%" PRIXPTR " %16s %*s %*s %*s %*s", &start, &end, tmpProt) > 0)
				{
					if (tmpProt[0] != 'r')
					{
						tmp.push_back({start, end});
					}
				}
			}
			fclose(f);
		}
		trapRegions = tmp;
		auto td = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count() - t1;
		std::this_thread::sleep_for(std::chrono::milliseconds(std::max(std::min(0LL, SLEEP_TIME - td), SLEEP_TIME)));
	}
}
void *main_thread(void *)
{
	LOGI("MainThread Started");
	UE4 = Tools::GetBaseAddress("libUE4.so");
	while (!UE4)
	{
		UE4 = Tools::GetBaseAddress("libUE4.so");
		sleep(1);
	}

	while (!g_App)
	{
		g_App = *(android_app **)(UE4 + GNativeAndroidApp_Offset);
		sleep(1);
	}
    while (!g_App->onInputEvent)
        sleep(1);
    orig_onInputEvent = decltype(orig_onInputEvent)(g_App->onInputEvent);
    g_App->onInputEvent = onInputEvent;
    Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libEGL.so"), OBFUSCATE("eglSwapBuffers")), (void *) _eglSwapBuffers, (void **) &orig_eglSwapBuffers);
	pthread_t t;
	pthread_create(&t, nullptr, maps_thread, nullptr);
	new std::thread(Messages);// Update Msg
	//new std::thread(GetNewMessages);// Get New Msg
	return nullptr;
}

__attribute__((constructor)) void _init()
{
	pthread_t t;
	pthread_create(&t, 0, main_thread, 0);
}
